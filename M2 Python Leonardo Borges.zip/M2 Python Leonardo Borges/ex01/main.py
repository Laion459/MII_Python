# ATIVIDADE PRÁTICA T1 – M2

    # 01)   Faça um programa, com validação de dados (try/exception)
    #       que receba a temperatura média de cada mês do ano e armazene-as em
    #       uma lista.
    #
    #       Em seguida calcule a média anual das temperaturas e
    #
    #       mostre a média calculada
    #
    #       juntamente com todas as temperaturas acima da média atual, e em que mês elas ocorreram.
    #
    #       Apresentar o nome do mês (sigla ou por extenso) e a lista de todas as temperaturas digitadas.


if __name__ == '__main__':
    print(' Exercicio 1 ')
    print(" Digite as temperaturas dos 12 meses do ano")


    lista = []
    listaAcimaDaMedia = []
    soma = 0
    media = 0
    meses = [
        "JAN", "FEV", "MAR", "ABR", "MAI", "JUN",
        "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"
    ]
    separacao = '-' * 50

    for i in range(12):
        while True:
            try:
                valor = float(input(f" Digite o {i + 1}° temperatura: "))
                if valor < 1 or valor > 70:
                    print(" Temperatura inválida! Insira uma temperatura válida entre 1°C e 70°C. ")
                else:
                    lista.append(valor)
                    i += 1
                    soma += valor
                    break
            except ValueError:
                print(" Valor inserido não é um número válido. Tente novamente. ")

    media = soma / 12
    for indice, item in enumerate(lista):
        if item > media:
            listaAcimaDaMedia.append((indice, item))


    print(separacao)
    print(f" - As temperaturas digitadas foram:............{lista}")
    print(f" - A temperatura média anual é de:.............{media}°C")
    print(f" - Meses com temperaturas acima da média: ")
    for indice, mes in listaAcimaDaMedia:
        print(f"    - Mês {indice + 1} - {meses[indice]} -> {mes:.2f}°C")

