# ATIVIDADE PRÁTICA T1 – M2

# 02)   Faça um programa de compras de um supermercado que
#       contenha uma lista com o nome do produto, a
#       quantidade,
#       preço unitário,
#       valor total dos produtos vendidos.
#
#       Não podem ser inseridos produtos com o mesmo nome,
#       valores de quantidade ou
#       preço com valores negativos ou iguais a zero.
#
#       Ao final o programa deve exibir a quantidade produtos cadastrados;
#       total de vendas de todos os produtos; as
#       informações de cada produto cadastrado na lista; o
#       nome e a
#       quantidade do produto mais vendido (Caso haja valores repetidos pode exibir o primeiro ou o último
#       produto classificado como maior).

if __name__ == '__main__':
    separacao = '=' * 80
    print(separacao)

    lista = []
    produtosCadastrados = 0
    total = 0
    maisVendido = {"nome": None, "quantidade": 0}

    while True:
        while True:
            nome = input("Digite o nome do produto: ")
            if nome in [item[0] for item in lista]:
                print("Nome já cadastrado. Tente novamente.")
            else:
                break

        while True:
            try:
                quantidade = int(input("Digite a quantidade: "))
                if quantidade < 1:
                    print("Quantidade inválida! Deve ser maior que zero.")
                else:
                    break
            except ValueError:
                print("Quantidade inválida! Deve ser um número inteiro.")

        while True:
            try:
                precoUnitario = float(input("Digite o preço unitário R$: "))
                if precoUnitario < 0:
                    print("Preço inválido! Deve ser maior ou igual a zero.")
                else:
                    total += quantidade * precoUnitario
                    break
            except ValueError:
                print("Preço inválido! Deve ser um número real.")

        lista.append((nome, quantidade, precoUnitario))
        produtosCadastrados += 1

        if quantidade > maisVendido["quantidade"]:
            maisVendido["nome"] = nome
            maisVendido["quantidade"] = quantidade

        resp = input("Deseja cadastrar novo produto? -> SIM (qualquer tecla) || NÃO (X): ").upper()
        if resp == 'X':
            break

    print(separacao)
    print(f" - Foram cadastrados: {produtosCadastrados} produtos.")
    print(f" - Total de compras: R$ {total}")
    print(f" - Detalhando os produtos:")
    for produto in lista:
        nome, quantidade, precoUnitario = produto
        valorTotal = quantidade * precoUnitario
        print(f"   - Produto {nome}, - vendeu {quantidade} unidades - Preço Unitário: R$ {precoUnitario:.2f} -  Total: R$ {valorTotal:.2f}")

    print(f" - O produto mais vendido foi: {maisVendido['nome']} com {maisVendido['quantidade']} unidades.")